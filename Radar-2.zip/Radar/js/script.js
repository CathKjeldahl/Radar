        // Scroll event to move the image vertically based on scroll position
        window.addEventListener('scroll', function () {
            var scrollPosition = window.scrollY; // Get the scroll position
            var image = document.querySelector('.forsidefoto img');
            
            // Move the image vertically based on scroll position
            // You can adjust the multiplier for faster/slower movement
            image.style.transform = 'translateY(' + scrollPosition * 0.3 + 'px)';
        });